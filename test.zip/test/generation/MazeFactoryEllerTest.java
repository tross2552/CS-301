package generation;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author megretson
 *
 */
public class MazeFactoryEllerTest { 
	
	
	
	
	/* To generate a new maze:
	 * 	1. Create stub order and set:
	 * 		a. builder
	 * 		b. deterministic
	 * 		c. skill
	 * 		d. perfect
	 * 	2. Tell it to start generating the maze
	 * 		a. Call stub.factory.order(stub)
	 * 			- stub's factory creates new thread
	 * 	3. Call stub.factory.waitTillDelivered()
	 * 			- when finished, factory's builder calls stub.deliver,
	 * 			  which updates mazeConfig to the new maze
	 * 	4. MazeConfiguration maze = stub.mazeConfig
	 * 
	 * Actually, just wrote steps 2-4 into a method stub.order() 
	 * 
	 */
	
	/*1. Test of MazeBuilder() 
	 * 	The random of one mazeBuilder should not equal the random of another mazeBuilder object
	 * 2. Test of MazeBuilder(boolean deterministic)
	 * 	A. If deterministic == FALSE then the random instances should be different from one another 
	 * 		across two objects
	 * 	B. If deterministic == TRUE then the random instances must be the same as one another
	 * 3. buildOrder dimensions
	 * 	A. The dimensions for two rooms of the same skill level are alsways the same as one another
	 * 	B. If the maze is perfect, then the rooms should always equal zero
	 * 	C. If the maze is not perfect, the number of rooms must be correct (equal to input)
	 * 	D. TODO: what is a partitier?
	 * 4. Run()
	 * 	A. Test the try catch block. Start by throwing a massive maze at the computer. Do not use
	 * 		the tillDelievered method. Instead, immediately throw an escape order to the computer. 
	 * 		This should trigger the exception InterruptedException ex. TODO: figure out how to send 
	 * 		given key input to the listener 
	 * 	B. Check if this is delievering a mazeConfig withh the correct paramters to order.deliever
	 * 5. Reset()
	 * 	The reset method must do that
	 * 6. generateRooms()
	 * 	This is almost entirely dependent on placeRoom so test that more than this
	 * 7. placeRoom()
	 * 	A. Try to send values which will put a room off the map (overflow / underflow cases)
	 * 	B. Make a test for each of the control statements 
	 * 8. generate()
	 * 	A. The exit generation need not be tested necessarily, however, our code needs to properly 
	 * 		initialize our cells in such a way that the distance functions can be used. 
	 * 9. generatePathways()
	 * 	A. pick a random point in the maze. 
	 * 	B. Follow some solving alogrithm. If a spot can be effectively reached, store that as True
	 * 		in a secondary array. 
	 * 	C. If, after the solving algorithm is done, there are any spots with false, there is either
	 * 		an isolation or a closed circuit. The maze is not perfect. 
	 * 
	 * */

}
