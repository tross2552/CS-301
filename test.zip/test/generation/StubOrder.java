package generation;

import generation.Order.Builder;

public class StubOrder implements Order {
	
	public MazeConfiguration mazeConfig;
	public int skill;
	public Builder builder;
	public boolean perfect;
	public Factory factory;
	public boolean deterministic;
	
	public StubOrder() {
		mazeConfig = new MazeContainer();
		factory = new MazeFactory();
	}
	
	public StubOrder(Builder b, int s, boolean p, boolean d) {
		this.setBuilder(b);
		this.setSkillLevel(s);
		this.setPerfect(p); 
		this.setDeterministic(d);
	}
	
	/**
	 * based on current field values, generate
	 * a new maze
	 */
	public MazeConfiguration order() {
		factory.order(this);
		factory.waitTillDelivered();
		return mazeConfig;
		
	}
	
	public MazeConfiguration getMazeConfiguration() {
		return mazeConfig;
		
	}

	@Override
	public int getSkillLevel() {
		// TODO Auto-generated method stub
		return this.skill;
	}
	
	public void setSkillLevel(int skill) {
		this.skill = skill;
	}

	@Override
	public Builder getBuilder() {
		// TODO Auto-generated method stub
		return this.builder;
	}
	
	public void setBuilder(Builder builder) {
		this.builder = builder;
	}

	@Override
	public boolean isPerfect() {
		// TODO Auto-generated method stub
		return this.perfect;
	}
	
	public void setPerfect(boolean perfect) {
		this.perfect = perfect;
	}
	
	
	public boolean isDeterministic() {
		// TODO Auto-generated method stub
		return this.deterministic;
	}
	
	public void setDeterministic(boolean deterministic) {
		this.deterministic = deterministic;
		factory = new MazeFactory(deterministic);
	}
	
	
	
	public MazeConfiguration getMazeConfig() {
		return mazeConfig;
	}
	
	@Override
	public void deliver(MazeConfiguration mazeConfig) {
		// TODO Auto-generated method stub
		this.mazeConfig = mazeConfig ;

	}


	@Override
	public void updateProgress(int percentage) {
		// TODO Auto-generated method stub
		//dont need anything here, just have to satisfy compiler
	}
	

	
	

}
