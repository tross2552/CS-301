package falstad;

import generation.CardinalDirection;
import generation.Factory;
import generation.MazeConfiguration;
import generation.MazeContainer;
import generation.MazeFactory;
import generation.Order;

/**
 * This is a stub class created to directly manipulate order fields for the sake of testing.
 * It simulates the behavior of MazeController when passed into MazeFactory. 
 * @author  Meg Anderson and Trenten Ross
 * @version 2.0
 * @since   2017-09-23
 */

public class StubMazeController extends MazeController implements Order {
	
	
	public int skill;
	public Builder builder;
	public boolean perfect;
	public Factory factory;
	public boolean deterministic;
	
	public boolean won;
	public int steps;
	public float batteryLevel;

	// current position and direction with regard to MazeConfiguration
	
	// Filename if maze is loaded from file
	private String filename;
	
	public StubMazeController() {
		setBuilder(Builder.DFS); 
		mazeConfig = new MazeContainer();
		factory = new MazeFactory();
		filename = null;
		setCurrentDirection(1, 0) ; // east direction
		//order();
	}
	
	public StubMazeController(Builder b, int s, boolean p, boolean d) {
		this.setBuilder(b);
		this.setSkillLevel(s);
		this.setPerfect(p); 
		this.setDeterministic(d);
		mazeConfig = new MazeContainer();
	}
	
	public StubMazeController(String filename) {
		this();
		this.filename = filename;
	}
	
	/**
	 * Loads maze from file and returns a corresponding maze configuration.
	 * @param filename
	 */
	@Override
	protected MazeConfiguration loadMazeConfigurationFromFile(String filename) {
		// load maze from file
		MazeFileReader mfr = new MazeFileReader(filename) ;
		// obtain MazeConfiguration
		return mfr.getMazeConfiguration();
	}
	
	/**
	 * Method to initialize internal attributes. Called separately from the constructor. 
	 */
	@Override
	public void init() {
		// special case: load maze from file
		if (null != filename) {
			//setState(StateGUI.STATE_GENERATING);
			// push results into controller, imitating maze factory delivery
			deliver(loadMazeConfigurationFromFile(filename));
			// reset filename, next round will be generated again
			if(getMazeConfiguration().getMazecells()==null) System.out.println(111);
			filename = null;
			return;
		}
		// common case: generate maze with some algorithm
		assert null != factory : "MazeController.init: factory must be present";
		//state = StateGUI.STATE_TITLE;
		factory.order(this);
		factory.waitTillDelivered();
		if(getMazeConfiguration().getMazecells()==null) System.out.println(111);
	}
	
	/**
	 * based on current field values, generate
	 * a new maze
	 */
	public MazeConfiguration order() {
		factory.order(this);
		factory.waitTillDelivered();
		return mazeConfig;
		
	}

	@Override
	public int getSkillLevel() {
		return this.skill;
	}
	
	public void setSkillLevel(int skill) {
		this.skill = skill;
	}

	@Override
	public Builder getBuilder() {
		
		return this.builder;
	}
	
	public void setBuilder(Builder builder) {
		this.builder = builder;
	}

	@Override
	public boolean isPerfect() {
		
		return this.perfect;
	}
	
	public void setPerfect(boolean perfect) {
		this.perfect = perfect;
	}
	
	
	public boolean isDeterministic() {
		
		return this.deterministic;
	}
	
	public void setDeterministic(boolean deterministic) {
		this.deterministic = deterministic;
		factory = new MazeFactory(deterministic);
	}	
	
	

	/**
	 * Performs a rotation with 4 intermediate views, 
	 * updates the screen and the internal direction
	 * @param dir for current direction
	 */
	@Override
	synchronized protected void rotate(int dir) {
		int angle = 0;
		final int originalAngle = angle;
		final int steps = 4;

		for (int i = 0; i != steps; i++) {
			angle = originalAngle + dir*(90*(i+1))/steps; 
		}
		
		setCurrentDirection((int) Math.cos(radify(angle)), (int) Math.sin(radify(angle))) ;
	}
		
	/**
	 * Moves in the given direction with 4 intermediate steps,
	 * updates the screen and the internal position
	 * @param dir, only possible values are 1 (forward) and -1 (backward)
	 */
	synchronized private void walk(int dir) {
		if (!checkMove(dir))
			return;
		setCurrentPosition(px + dir*dx, py + dir*dy) ;
	}

	/**
	 * checks if the given position is outside the maze
	 * @param x
	 * @param y
	 * @return true if position is outside, false otherwise
	 */
	private boolean isOutside(int x, int y) {
		return !mazeConfig.isValidPosition(x, y) ;
	}
	
	/**
	 * Method incorporates all reactions to keyboard input in original code, 
	 * The simple key listener calls this method to communicate input.
	 */
	@Override
	public boolean keyDown(UserInput key, int value) {
		operateGameInPlayingState(key);
		return true;
	}
	
	/**
	 * Method responds to user input when the user explores the maze. 
	 * @precondition current state is STATE_PLAY
	 * @param key is the user input 
	 */
	@Override
	protected void operateGameInPlayingState(UserInput key) {
		// react to input for directions and interrupt signal (ESCAPE key)	
		// react to input for displaying a map of the current path or of the overall maze (on/off toggle switch)
		// react to input to display solution (on/off toggle switch)
		// react to input to increase/reduce map scale
		switch (key) {
		case Up: // move forward
			walk(1);
			if (isOutside(px,py)) {
				won=true;
			}
			break;
		case Left: // turn left
			rotate(1);
			break;
		case Right: // turn right
			rotate(-1);
			break;
		case Jump: // make a step forward even through a wall
			// go to position if within maze
			if (mazeConfig.isValidPosition(px + dx, py + dy)) {
				setCurrentPosition(px + dx, py + dy) ;
			}
			break;
		default: break;
		} // end of internal switch statement for playing state
	}
	
	@Override
	public void deliver(MazeConfiguration mazeConfig) {
		this.mazeConfig = new MazeContainer(); 
		this.mazeConfig = mazeConfig ;
		// obtain starting position
		int[] start = this.mazeConfig.getStartingPosition() ;
		setCurrentPosition(start[0],start[1]) ;
		MazeContainer mc = (MazeContainer) this.mazeConfig;
		MazeContainer mc2 = (MazeContainer) mazeConfig;
		mc.mazecells = mc2.getMazecells();
		this.mazeConfig = mc;
		if(this.mazeConfig.getMazecells()==null )System.out.println(9);
		else System.out.println(8);
	}
	
	@Override
	public void switchToFinishScreen() {
		
	}
	
	

	

}
